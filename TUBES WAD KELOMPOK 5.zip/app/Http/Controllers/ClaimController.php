<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ClaimController extends Controller
{
    public function index()
    {
        return view('claim.Klaim');
    }

    public function store(Request $request)
    {
        dd($request->all());
    }
}
