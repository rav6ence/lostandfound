<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\FoundItem;
use App\Models\Location;
use Illuminate\Support\Facades\Storage;

class FoundItemController extends Controller
{
    public function index()
    {
        $items = FoundItem::all();
        return view('found_items.index', compact('items'));
    }

    public function create()
    {
        $locations = Location::all();
        return view('found_items.create', compact('locations'));
    }

    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'nama_barang'      => 'required|string|max:255',
            'kondisi'          => 'required',
            'deskripsi_barang' => 'required',
            'tanggal_temukan'  => 'required|date',
            'waktu_temukan'    => 'required',
            'lokasi_penemuan'  => 'required',
            'kronologi'        => 'required',
            'nama_penemu'      => 'required',
            'kontak_penemu'    => 'required',
            'alamat_penemu'    => 'required',
            'image'            => 'nullable|image|mimes:jpeg,png,jpg|max:2048'
        ]);

        if ($request->hasFile('image')) {
            $path = $request->file('image')->store('found_items', 'public');
            $validatedData['image'] = $path;
        }

        FoundItem::create($validatedData);

        return redirect()
            ->route('found-items.index')
            ->with('success', 'Laporan barang ditemukan berhasil ditambahkan');
    }

    public function edit(string $id)
    {
        $item = FoundItem::findOrFail($id);
        $locations = Location::all();
        return view('found_items.create', compact('item', 'locations'));
    }

    public function update(Request $request, string $id)
    {
        $item = FoundItem::findOrFail($id);

        $validatedData = $request->validate([
            'nama_barang'      => 'required|string|max:255',
            'kondisi'          => 'required',
            'deskripsi_barang' => 'required',
            'tanggal_temukan'  => 'required|date',
            'waktu_temukan'    => 'required',
            'lokasi_penemuan'  => 'required',
            'kronologi'        => 'required',
            'nama_penemu'      => 'required',
            'kontak_penemu'    => 'required',
            'alamat_penemu'    => 'required',
            'image'            => 'nullable|image|mimes:jpeg,png,jpg|max:2048'
        ]);

        if ($request->hasFile('image')) {
            if ($item->image) {
                Storage::disk('public')->delete($item->image);
            }
            $path = $request->file('image')->store('found_items', 'public');
            $validatedData['image'] = $path;
        }

        $item->update($validatedData);

        return redirect()
            ->route('found-items.index')
            ->with('success', 'Laporan barang ditemukan berhasil diperbarui');
    }

    public function destroy(string $id)
    {
        $item = FoundItem::findOrFail($id);
        
        if ($item->image) {
            Storage::disk('public')->delete($item->image);
        }

        $item->delete();

        return redirect()
            ->route('found-items.index')
            ->with('success', 'Laporan barang ditemukan berhasil dihapus');
    }
}