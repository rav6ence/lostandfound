<?php

namespace App\Http\Controllers;

use App\Models\LostItem;
use App\Models\Location;
use App\Models\Category;
use Illuminate\Http\Request;

class LostItemController extends Controller
{
    public function index()
    {
        $items = LostItem::with('location', 'category')->get();
        return view('lost_items.index', compact('items'));
    }

    public function create()
    {
        $locations  = Location::all();
        $categories = Category::all();

        return view('lost_items.create', compact('locations', 'categories'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'nama_barang'    => 'required',
            'category_id'    => 'required|exists:categories,id',
            'location_id'    => 'required|exists:locations,id',
            'status_id'      => 'required',
            'tanggal_hilang' => 'required|date',
            'deskripsi'      => 'nullable',
            'kontak'         => 'required'
        ]);

        LostItem::create($validated);

        return redirect()
            ->route('lost-items.index')
            ->with('success', 'Laporan barang hilang berhasil ditambahkan');
    }

    public function show($id)
    {
        $item = LostItem::with('location', 'category')->find($id);

        if (!$item) {
            return redirect()
                ->route('lost-items.index')
                ->with('error', 'Data laporan tidak ditemukan');
        }

        return view('lost_items.show', compact('item'));
    }

    public function edit($id)
    {
        $item       = LostItem::find($id);
        $locations  = Location::all();
        $categories = Category::all();

        if (!$item) {
            return redirect()
                ->route('lost-items.index')
                ->with('error', 'Data laporan tidak ditemukan');
        }

        return view('lost_items.edit', compact('item', 'locations', 'categories'));
    }

    public function update(Request $request, $id)
    {
        $item = LostItem::find($id);

        if (!$item) {
            return redirect()
                ->route('lost-items.index')
                ->with('error', 'Data laporan tidak ditemukan');
        }

        $validated = $request->validate([
            'nama_barang'    => 'required',
            'kategori'        => 'required|string',
            'lokasi_terakhir' => 'required|string',
            'status_id'      => 'required',
            'tanggal_hilang' => 'required|date',
            'deskripsi'      => 'nullable',
            'kontak'         => 'required'
        ]);

        $item->update($validated);

        return redirect()
            ->route('lost-items.index')
            ->with('success', 'Laporan barang hilang berhasil diperbarui');
    }

    public function destroy($id)
    {
        $item = LostItem::find($id);

        if (!$item) {
            return redirect()
                ->route('lost-items.index')
                ->with('error', 'Data laporan tidak ditemukan');
        }

        $item->delete();

        return redirect()
            ->route('lost-items.index')
            ->with('success', 'Laporan barang hilang berhasil dihapus');
    }
}