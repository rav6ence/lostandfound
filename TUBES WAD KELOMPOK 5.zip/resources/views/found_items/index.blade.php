@extends('layouts.app')

@section('title', 'Daftar Barang Ditemukan')

@section('content')
<div class="mb-3">
    <h4 class="mb-0">Daftar Barang Ditemukan</h4>
</div>

<table>
    <thead>
        <tr>
            <th>No</th>
            <th>Foto</th>
            <th>Nama Barang</th>
            <th>Kategori</th>
            <th>Lokasi</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        @forelse($items as $i => $item)
        <tr>
            <td>{{ $i + 1 }}</td>
            <td>
                @if($item->foto)
                    <img src="{{ asset('storage/' . $item->foto) }}" width="50" height="50" alt="Foto Barang" style="object-fit:cover; border-radius:4px;">
                @else
                    <div style="width:50px;height:50px;background:#eee;text-align:center;line-height:50px;font-size:10px;color:#999;">No Pic</div>
                @endif
            </td>
            <td>{{ $item->nama_barang }}</td>
            <td>{{ $item->kategori ?? '-' }}</td>
            <td>{{ $item->lokasi ?? '-' }}</td>
            <td>
                <a href="#" class="btn btn-green btn-sm">Klaim</a>
                <a href="{{ route('found-items.show', $item->id) }}" class="btn btn-info btn-sm">Detail</a>
                <a href="{{ route('found-items.edit', $item->id) }}" class="btn btn-yellow btn-sm">Edit</a>
                <form action="{{ route('found-items.destroy', $item->id) }}" method="POST" style="display:inline-block;" onsubmit="return confirm('Yakin hapus?')">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn btn-red btn-sm">Hapus</button>
                </form>
            </td>
        </tr>
        @empty
        <tr>
            <td colspan="6" style="text-align:center;color:#888;">Belum ada laporan.</td>
        </tr>
        @endforelse
    </tbody>
</table>
@endsection
