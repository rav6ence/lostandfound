

<?php $__env->startSection('content'); ?>
<h3>Daftar Barang Hilang</h3>
<a href="<?php echo e(route('lost-items.create')); ?>" class="btn btn-primary mb-3">Tambah Laporan</a>

<table class="table table-bordered">
    <tr>
        <th>Nama Barang</th>
        <th>Lokasi</th>
        <th>Aksi</th>
    </tr>
    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($item->nama_barang); ?></td>
        <td><?php echo e($item->lokasi); ?></td>
        <td>
            <a href="<?php echo e(route('lost-items.show', $item->id)); ?>" class="btn btn-info btn-sm">Detail</a>
            <a href="<?php echo e(route('lost-items.edit', $item->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
            <form action="<?php echo e(route('lost-items.destroy', $item->id)); ?>" method="POST" style="display:inline;">
                <?php echo csrf_field(); ?>
                <button class="btn btn-danger btn-sm" onclick="return confirm('Hapus?')">Hapus</button>
            </form>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\belajar\xampp\htdocs\tubes\lostandfound\resources\views/lost_items/index.blade.php ENDPATH**/ ?>