

<?php $__env->startSection('content'); ?>
<h3>Tambah Barang Hilang</h3>

<form method="POST" action="<?php echo e(route('lost-items.store')); ?>">
<?php echo csrf_field(); ?>

<input name="nama_barang" class="form-control mb-2" placeholder="Nama Barang">

<select name="kategori" class="form-control mb-2">
    <option value="elektronik">Elektronik</option>
    <option value="dokumen">Dokumen</option>
    <option value="aksesoris">Aksesoris</option>
    <option value="lainnya">Lainnya</option>
</select>

<select name="location_id" class="form-control mb-2">
    <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($location->id); ?>"><?php echo e($location->nama_lokasi); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>

<select name="status" class="form-control mb-2">
    <option value="hilang">Hilang</option>
    <option value="ditemukan">Ditemukan</option>
</select>

<input type="date" name="tanggal_hilang" class="form-control mb-2">

<textarea name="deskripsi" class="form-control mb-2"></textarea>

<input name="kontak" class="form-control mb-2" placeholder="Kontak">

<button class="btn btn-primary">Simpan</button>
</form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\belajar\xampp\htdocs\tubes\lostandfound\resources\views/lost_items/create.blade.php ENDPATH**/ ?>