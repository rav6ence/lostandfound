<!DOCTYPE html>
<html>
<head>
    <title>Lost and Found</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
    <div class="container">
        <a class="navbar-brand" href="/">Lost & Found</a>
        <div>
            <a href="<?php echo e(route('lost-items.index')); ?>" class="btn btn-outline-light btn-sm">Barang Hilang</a>
            <a href="<?php echo e(route('found-items.index')); ?>" class="btn btn-outline-light btn-sm">Barang Ditemukan</a>
            <a href="<?php echo e(route('locations.index')); ?>" class="btn btn-outline-light btn-sm">Lokasi</a>
        </div>
    </div>
</nav>

<div class="container">
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <?php echo $__env->yieldContent('content'); ?>
</div>

</body>
</html>
<?php /**PATH D:\belajar\xampp\htdocs\tubes\lostandfound\resources\views/layouts/app.blade.php ENDPATH**/ ?>